public class Funcionario {
    public String nome;
    public float salario;

    public Funcionario(String nome, float salario) {
        this.nome = nome;
        this.salario = salario;
    }
}
