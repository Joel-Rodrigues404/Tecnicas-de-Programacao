public class Main {
    public static void main(String[] args) {
        Gerente gerente = new Gerente("Alice", 100f);

        System.out.println(gerente.exibirBonus());
    }
}
