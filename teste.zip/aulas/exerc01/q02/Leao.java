public class Leao extends Animal {
    @Override
    public void emitirSom() {
        System.out.println("som de Leao");
    }
}
