public class Main {
    public static void main(String[] args) {
        Cliente cliente1 = new Cliente("joel", "10101010101");

        System.out.println(cliente1.exibirDados());
    }
}
